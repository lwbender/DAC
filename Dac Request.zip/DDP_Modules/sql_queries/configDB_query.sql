select * 

from 
vwDosimeterDoseCalcCoefficients as c 